package com.provider.asc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
